#!/usr/bin/python

from __future__ import division
import sys
import getopt
import datetime
import importlib
import Mutation_Modules
from Bio.PDB import *

# Define input files and output files 
def main(argv):
	inputfile= ''
	pdbfile= ''
	outputfile= ''
	try:
		opts, args = getopt.getopt(argv,"hi:p:o:",["ifile=","pdb=","ofile="])
	except getopt.GetoptError:
		print 'God.py -i <inputfile> -p <pdbfile> -o <outputfile>'
		sys.exit(2)
	for opt, arg in opts:
		if opt == '-h':
			print 'Usage: God.py -i <inputfile> -o <outputfile>'
			sys.exit()
		elif opt in ("-i", "--ifile"):
			inputfile = arg
		elif opt in ("-p", "--pdb"):
			pdbfile = arg
		elif opt in ("-o", "--ofile"):
			outputfile = arg
	return inputfile, pdbfile, outputfile
if __name__ == "__main__":
	main(sys.argv[1:])
# Create output file and timestamp it
outfile=open(main(sys.argv[1:])[2], 'w+')
rightnow = str(datetime.datetime.now().strftime('DATE: %Y/%m/%d TIME: %H:%M:%S'))
outfile.write(rightnow + '\n' )
# Define dictionary of input files
inf = {}
# Load up input file
f = open(main(sys.argv[1:])[0])
# Parse input, assign values to variables
data = f.readlines()
for line in data:
    key, value = line.split("=")
    inf[key.strip()] = value.strip()
f.close()
# Convert strings to integers
inf['residue'] = int(inf['residue'])
# Read in PDB file
parser = PDBParser(QUIET=True)
structure = parser.get_structure('Input_PDB',main(sys.argv[1:])[1])
vxi = structure[0][' '][inf['residue']]
beginaa = vxi.get_resname()
# Import correct mutation module
Curr_mut = 'Mutation_Modules.' + beginaa + '_' + inf['finalaa']
Curr_mut = importlib.import_module(Curr_mut)
# Save mutated pdb as Mutabond.pdb
io = Curr_mut.vxier()
io.set_structure(structure)
io.save('Mutabond.pdb', inf['residue'])
# Load parameters files
begparam = {}
with open('Param_files/%s.param' % (beginaa)) as f:
    data = f.readlines()[1:]
for line in data:
    key, value = line.split("=")
    begparam[key.strip()] = float(value.strip())
f.close()
finparam = {}
with open('Param_files/%s.param' % (inf['finalaa'])) as f:
    data = f.readlines()[1:]
for line in data:
    key, value = line.split("=")
    finparam[key.strip()] = float(value.strip())
f.close()
for i in range(11):
	i = i/10
	print "%.4f" % (begparam['CB_charge']+(finparam['CB_charge']-begparam['CB_charge'])*i)
	
